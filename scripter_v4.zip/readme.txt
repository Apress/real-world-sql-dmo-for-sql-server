Command Line Syntax
~~~~~~~~~~~~~~~~~~~
Scripter.exe  /s=ServerName
              /f=Output path. This path must exist
              [/u=Login]
              [/p=Password]
              [/b=BCP user data from all tables]		
              [/v=verbose logging]

Command Line Switches:
/s=ServerName
	ServerName = Name of the server to script from
/f=Output path.
	Path for output files. This path must already exist
[/u=Login]
	Login = Login to use to connect to the server. Leave empty for trusted connection.
[/p=Password]
	Password = Password to use to connect to the server. Leave empty for trusted connection.
[/b=BCP user data from all tables]
	BCPs all user data from all tables in native format. System tables are always BCP'd.
	Leave empty to only BCP system tables.
[/v=verbose logging]
	Adds detailed information to the log file. Every database object is logged. Creates a larger log file.
	Leave empty to create a smaller log file.

Examples
~~~~~~~~
c:\Scripter.exe /fc:\Scripts /sSERVER1 /b /v
	Connects to SERVER1 using trusted (NT) security and scripts out all database objects. 
	All data is BCP'd out and verbose logging is switched on.
c:\Scripter.exe /fc:\Scripts /sSERVER2 /usa /pyouwish
	Connects to SERVER2 using standard SQL Security and scripts out all database objects.
	Simple logging is used and only system tables are BCP'd out.


More information
~~~~~~~~~~~~~~~~
A log file is written to the application path in the format Log_yyyymmdd.log
a directory is built for each database within the specified /f file path.


Transfers Out:

Database Creation
Server Logins
Databases
Tables (and permissions)
Data
FKs
Procedures (and permissions)
Views (and permissions) 
Defaults
Rules
Roles
Users
Indexes
Full Text Catalogs
Replication
Local DTS Packages (not password protected ones)